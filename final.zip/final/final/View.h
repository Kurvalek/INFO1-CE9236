//
//  View.h
//  final
//
//  Created by Kathleen Urvalek on 8/11/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View : UIView {
    CGMutablePathRef drawing;
    UIImageView *imageView;
    UIButton *button;
}
- (void) clearPath;
@end
