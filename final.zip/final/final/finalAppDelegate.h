//
//  finalAppDelegate.h
//  final
//
//  Created by Kathleen Urvalek on 8/11/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface finalAppDelegate : NSObject <UIApplicationDelegate> {
    View *view;
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
