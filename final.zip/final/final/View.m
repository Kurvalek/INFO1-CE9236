//
//  View.m
//  final
//
//  Created by Kathleen Urvalek on 8/11/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "View.h"

@implementation View

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"chalkboard.png"]];
		drawing = CGPathCreateMutable();	//born empty
        
            }
    return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	CGPoint p = [[touches anyObject] locationInView: self];
	CGPathMoveToPoint(drawing, NULL, p.x, p.y);
}

- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {
	CGPoint p = [[touches anyObject] locationInView: self];
	CGPathAddLineToPoint(drawing, NULL, p.x, p.y);
	[self setNeedsDisplay];
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
	CGContextRef c = UIGraphicsGetCurrentContext();
	CGContextBeginPath(c);
	CGContextAddPath(c, drawing);
	CGContextSetRGBStrokeColor(c, 1, 1, 1, 1);	
    CGContextSetLineWidth (c, 4);
	CGContextStrokePath(c);
}

- (void) clearPath {
	CGPathRelease(drawing);
	drawing = CGPathCreateMutable();
	[self setNeedsDisplay];
}

- (void) dealloc {
	CGPathRelease(drawing);
	[super dealloc];
}

@end