//
//  finalTests.h
//  finalTests
//
//  Created by Kathleen Urvalek on 8/11/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface finalTests : SenTestCase

@end
